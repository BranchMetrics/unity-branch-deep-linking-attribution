//
//  BNCDebugRequest.h
//  Branch-TestBed
//
//  Created by Graham Mueller on 8/4/15.
//  Copyright © 2015 Branch Metrics. All rights reserved.
//
//  This class is basically just a marker interface.

#import "BNCServerRequest.h"

@interface BNCDebugRequest : BNCServerRequest

@end
