﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class CreditTransactionItem : MonoBehaviour {

	public Text label;
}
